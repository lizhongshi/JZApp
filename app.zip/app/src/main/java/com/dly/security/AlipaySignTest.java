package com.dly.security;

import java.io.IOException;



public class AlipaySignTest {

    // 签名密钥
    private static final String SIGN_KEY = "abcdefghijk";

    /**
     * 签名算法
     *
     * @param args
     * @throws CryptException
     * @throws IOException
     */
//    public static void main(String[] args) throws CryptException {
//        String[] billNos = { "4403101092604773", "4403062709507321", "4403061093040707",
//                             "4403081701486046" };
////
////        for (String billNo : billNos) {
////            System.out.println("缴费单号：" + billNo);
//            // billNo加上密钥一起签名，data数组中的值无排列顺序。签名时会按字典序自动拼接
//        
//        
//            String[] data = new String[] { "sygjj", "123" };
//            // 生成签名
//            String sign = SHA1.genSign(data);
//            System.out.println("签名结果：" + sign);
//            // 校验签名
////            String sign2="6d10b596d61ae8982db9b8fc09940486c7db5914";
//            boolean verifySign = SHA1.verifySign(data, sign);
//            System.out.println("签名校验结果：" + verifySign);
////        }
//
//    }

}
