package com.dly.app.base;



import java.util.Map;
/**
 * 接口返回封装类
 * @author 12622
 *
 */
public class Result {
	private static Result result;
	private String struts;//成功或者失败
	private String code;//状态码
	private String msg;//成功的消息
	private String error;//失败的消息
	private Map<String,String> data;//返回的数据
	
	public Result () {
		
	}
	public Result(String struts, String code, String msg, String error, Map<String,String> data) {
		this.struts = struts;
		this.code = code;
		this.msg = msg;
		this.error = error;
		this.data = data;
	}
	public Result(String struts, String code, String msg, String error) {
		this.struts = struts;
		this.code = code;
		this.msg = msg;
		this.error = error;
	
	}

	
	public String isStruts() {
		return struts;
	}
	public void setStruts(String struts) {
		this.struts = struts;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public Map<String,String> getData() {
		return data;
	}
	public void setData(Map<String,String> data) {
		this.data = data;
	}


}
