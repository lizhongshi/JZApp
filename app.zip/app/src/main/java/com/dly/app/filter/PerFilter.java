package com.dly.app.filter;

import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.alibaba.fastjson.JSONObject;
/**
 * 前置过滤器
 * @author lzs
 *
 */
public class PerFilter implements Filter{

	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("filter");
	}

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		
	System.out.println("test filter");
	HttpServletRequest httpreq=(HttpServletRequest)req;
	MyHttpServletRequestWrapper myreq=new MyHttpServletRequestWrapper(httpreq);
	System.out.println(httpreq.getRequestURL());
	System.out.println(httpreq.getHeader(""));
	System.out.println(httpreq.getMethod());
	System.out.println(httpreq.getContentType());
	if("application/json;charset=UTF-8".equals(httpreq.getContentType())) {//访问接口时验证数据是否被篡改
		System.out.println("接口");
		BufferedReader br=myreq.getReader();
		String str, wholeStr = "";
		while((str = br.readLine()) != null){
		wholeStr += str;
		}
		System.out.println(wholeStr);
		JSONObject json=JSONObject.parseObject(wholeStr);
		System.out.println(json.get("username"));
		
		
		
	}
	
	
	chain.doFilter(myreq, res);
		  
	}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("filter init");
	}

}
