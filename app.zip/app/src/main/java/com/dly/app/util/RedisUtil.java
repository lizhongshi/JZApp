package com.dly.app.util;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

@Component
public class RedisUtil {
	  public static final String KEY_PREFIX_VALUE = "dg:report:value:";
	    public static final String KEY_PREFIX_SET = "dg:report:set:";
	    public static final String KEY_PREFIX_LIST = "dg:report:list:";
	@Resource
	private  RedisTemplate<String, String> redisTemplate;
	static Logger logger = Logger.getLogger(RedisUtil.class);
	 /**
     * 缓存value操作
     * @param key
     * @param value
     * @param 缓存的时间
     * @return
     */
    public   boolean cacheValue(String key, String value, long time) {

        try {
            ValueOperations<String, String> valueOps =  redisTemplate.opsForValue();
            
                 valueOps.set(key, value,time, TimeUnit.SECONDS);
            logger.info("缓存[" + key+ "], value[" + value + "]");
            return true;
        } catch (Throwable t) {
            logger.error("缓存[" + key + "]失败, value[" + value + "]", t);
        }
        return false;
    }
    

}
