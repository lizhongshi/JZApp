package com.dly.app.dao;

import java.util.Set;

import com.dly.app.entity.User;

public interface UserDao {
	public User login(User user);//登录
	public int register(User user);//注册
	/**
	 * 通过用户名查询角色信息
	 * @param userName
	 * @return
	 */
	public Set<String> getRoles(String userName);
	
	/**
	 * 通过用户名查询权限信息
	 * @param userName
	 * @return
	 */
	public Set<String> getPermissions(String userName);
	/**
	 * 修改用户登录状态
	 * @param username
	 * @return
	 */
	public int upstruts (String username);
}
