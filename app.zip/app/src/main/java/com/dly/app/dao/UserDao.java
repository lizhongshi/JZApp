package com.dly.app.dao;

import com.dly.app.entity.User;

public interface UserDao {
	public User login(User user);

}
