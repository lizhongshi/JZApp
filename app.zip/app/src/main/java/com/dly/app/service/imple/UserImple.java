package com.dly.app.service.imple;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.dly.app.base.Result;
import com.dly.app.dao.UserDao;
import com.dly.app.entity.User;
import com.dly.app.service.UserService;
import com.dly.app.util.RedisUtil;
import com.dly.app.util.Util;
@Service("userService")
public class UserImple extends Result implements UserService {
	@Resource
	private UserDao userDao;
	@Resource
	RedisUtil ru;
	 Logger logger = Logger.getLogger(UserImple.class);
	public Result login(User user) {
		User us= userDao.login(user);
		if(us==null) {
			return new Result("false","99","用户名密码错误","") ;
		}
		String salt= us.getSalt();//获取用户盐值
		String password=Util.Md5(user.getPassword(), salt);
		Subject subject=SecurityUtils.getSubject();
		UsernamePasswordToken token=new UsernamePasswordToken(user.getUsername(), password);//传入密码
		System.out.println("账户"+user.getUsername()+"++++"+"密码++++++"+password);
		try{
			subject.login(token);//登录
			
			
			System.out.println(us);
			String tokenid=Util.getUUID();
			ru.cacheValue(us.getUsername(), tokenid, 3000);//缓存tokenid 300秒
			/**
			 * 留着等手机用
			 */
//			if(us.getStruts().equals("1")) {//用户状态被冻结
//				return new Result("false","98","用户已登录","") ;
//			}else {//未登录
//				userDao.upstruts(us.getUsername());//修改用户状态
//			}
			
			Session session=subject.getSession();
			System.out.println("sessionId:"+session.getId());
			System.out.println("sessionHost:"+session.getHost());
			System.out.println("sessionTimeout:"+session.getTimeout());
			session.setAttribute("info", "session的数据");
			List list =new ArrayList();
			Map map=new HashMap();
			map.put(us.getNickname(), us);
			//list.add(map);
			return new Result("true","0","登录成功","",map) ;
		}catch(Exception e){
			e.printStackTrace();
			
			return new Result("false","99","用户名密码错误",e.getMessage()) ;
		}
		
		
		

	}

	public Result register(User user) {
		User  us= userDao.login(user);
		//System.out.println(us);
		if(us!=null){
			return new Result("false","99","已经存在用户","") ;
		}
		
		
		String salt=Util.getUUID();
		user.setSalt(salt);
		user.setToken(salt);
		user.setPassword(Util.Md5(user.getPassword(), salt));
		System.out.println(user);
		int lin=userDao.register(user);
		
		if(lin>0) {
			return new Result("true","0","注册成功","") ;
		}else {
			return new Result("false","99","注册失败","") ;
		}
		
	}

	public Set<String> getRoles(String userName) {
		return userDao.getRoles(userName);
	}

	public Set<String> getPermissions(String userName) {
		return userDao.getPermissions(userName);
	}


	

}
