package com.dly.app.controller;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;

import com.dly.app.base.Result;

import redis.clients.jedis.Jedis;

public class test extends Result implements  Runnable {

	public static void main(String[] args) {
		
//		Thread t1=null;
//		for (int i = 0; i <1000; i++) {
//			test t=new test();
//			
//			 t1=new Thread(t);
//			 t1.start();
//		}
//	Result r=	getResult();
//	r.setCode("2");
//	System.out.println(r);
//	Result r1=	getResult();
//		redis.clients.jedis.Jedis
		Jedis jedis =new Jedis("39.106.129.135",6379);
		jedis.auth("200814");
	Long s=jedis.getDB();
	
	System.out.println(s);
	jedis.set("ss","你好");
		System.out.println(jedis.get("3"));
		
	}

	public void run() {
		System.out.println(Thread.currentThread().getName());
		HttpClient httpClient = HttpClients.createDefault();
		
		Thread t1=null;
		for (int i = 0; i <1000; i++) {
			test t=new test();
			
			 t1=new Thread(t);
			 t1.start();
		}
	}

}
