package com.dly.app.controller;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClients;

import com.dlyshineyue.app.base.Result;

public class test extends Result implements  Runnable {

	public static void main(String[] args) {
		
//		Thread t1=null;
//		for (int i = 0; i <1000; i++) {
//			test t=new test();
//			
//			 t1=new Thread(t);
//			 t1.start();
//		}
//	Result r=	getResult();
//	r.setCode("2");
//	System.out.println(r);
//	Result r1=	getResult();
//		System.out.println(r1);
		
	}

	public void run() {
		System.out.println(Thread.currentThread().getName());
		HttpClient httpClient = HttpClients.createDefault();
		
		Thread t1=null;
		for (int i = 0; i <1000; i++) {
			test t=new test();
			
			 t1=new Thread(t);
			 t1.start();
		}
	}

}
