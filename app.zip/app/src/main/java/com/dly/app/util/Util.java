package com.dly.app.util;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.codec.digest.DigestUtils;

import com.alibaba.fastjson.JSONObject;
import com.dly.app.entity.User;
import com.dlyshineyue.app.base.Result;

public class Util {
	public static synchronized String getUUID() {
		String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		return uuid;
	}
	
	public static  String Md5(String pwd,String salt) {
		
		return DigestUtils.md5Hex(pwd+salt);
	}

	  
	public static void main(String[] args) {
		
		
		String id=getUUID();
		//System.out.println(id);
		
		String idd=Md5("123456","3749faf3b6954babaa2322124525c80b");
		System.out.println(idd);
		
	
	}
	
	public static Object poststr(Object o) {
//		JSONObject json=JSONObject.;
//		try {
//			json
//		}catch(Exception e) {
//			
//		}
		
		return null;
	}
	/**
	 * 验证登录
	 * @param user
	 * @param us
	 * @return
	 */
	public static Result  loginchenk(User user,User us) {
		String pass= user.getPassword();
		 String yz= us.getSalt();
		if(us.getPassword().equals( Md5(pass,yz))) {
			return new Result("true","0","验证成功","",new ArrayList()) ;
		}
		return new Result("false","99","用户名密码错误","") ;
	}

}
