package com.dly.app.serviceimple;



import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dly.app.dao.UserDao;
import com.dly.app.entity.User;
import com.dly.app.service.UserService;
import com.dly.app.util.Util;
import com.dlyshineyue.app.base.Result;
@Service("userService")
public class UserImple extends Result implements UserService {
	@Resource
	private UserDao userDao;
	
	public Result login(User user) {
		User us= userDao.login(user);
		if(us!=null) {
			return Util.loginchenk(user, us);
		}else {
			return new Result("false","99","用户名密码错误","") ;
		}

	}

	

}
