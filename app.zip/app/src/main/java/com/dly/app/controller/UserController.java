package com.dly.app.controller;


import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dly.app.dao.UserDao;
import com.dly.app.entity.User;
import com.dly.app.service.UserService;


@RequestMapping(value="test")
@RestController
public class UserController {
	@Resource
	private UserDao userdao;
	@Resource
	private UserService userService;
	@RequestMapping(value="test1")
	public Object  test() {
		String s="232";
	
		return s; 
	}
	
//	@RequestMapping(value="test2")
//	public ModelAndView  test1(ModelAndView mv) {
//		
//		
//		mv.setViewName("test"); 
//		return mv; 
//	}
	
	@RequestMapping(value="login",method=RequestMethod.POST)
	@ResponseBody
	public Object  login(HttpSession see,User user) {
		System.out.println(user);
		
		return userService.login(user);
	}
}
