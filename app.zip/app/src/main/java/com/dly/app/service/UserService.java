package com.dly.app.service;

import com.dly.app.entity.User;
import com.dlyshineyue.app.base.Result;

public interface UserService  {
	
	public Result login(User user);
	

}
