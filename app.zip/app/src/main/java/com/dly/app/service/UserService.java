package com.dly.app.service;

import java.util.Set;

import com.dly.app.base.Result;
import com.dly.app.entity.User;

public interface UserService  {
	/**
	 * 登录
	 * @param user
	 * @return
	 */
	public Result login(User user);//登录
	/**
	 * 注册
	 * @param user
	 * @return
	 */
	public Result register(User user);//注册
	/**
	 * 获取用户角色
	 * @param userName
	 * @return
	 */
	public Set<String> getRoles(String userName);
	
	/**
	 * ͨ获取权限
	 * @param userName
	 * @return
	 */
	public Set<String> getPermissions(String userName);

	

}
