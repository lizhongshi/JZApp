﻿package com.dly.app.shiro.realm;

import javax.annotation.Resource;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.subject.PrincipalCollection;

import com.dly.app.base.Result;
import com.dly.app.dao.UserDao;
import com.dly.app.entity.User;
import com.dly.app.service.UserService;
import com.dly.app.util.Util;

public class MyRealm  extends AuthorizingRealm{
	@Resource
	private UserDao  userDao;
	@Resource
	private UserService  userService;

	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		String userName=(String)principals.getPrimaryPrincipal();
		SimpleAuthorizationInfo authorizationInfo=new SimpleAuthorizationInfo();
		authorizationInfo.setRoles(userService.getRoles(userName));
		authorizationInfo.setStringPermissions(userService.getPermissions(userName));
		return authorizationInfo;
	}



	
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		String userName=(String)token.getPrincipal();
			User us=new User();
			us.setUsername(userName);
			User user=userDao.login(us);
			System.out.println("+++++++++++"+user);
			if(user!=null) {
				
				//System.out.println("账户"+user.getUsername()+"密码后+++++"+user.getPassword());
				 AuthenticationInfo authcInfo=new SimpleAuthenticationInfo(user.getUsername(),user.getPassword(),"xx");
				 return authcInfo;
			}else {
				return null;		
			}
			
			
			

	

	}

}
